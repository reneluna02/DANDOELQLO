import pywhatkit as kit

def enviar_mensaje(numero, mensaje):
    try:
        kit.sendwhatmsg_instantly(numero, mensaje)
        print(f"Mensaje enviado a {numero}")
    except Exception as e:
        print(f"Error al enviar mensaje: {e}")