import pytesseract
from PIL import Image

def escanear_texto(imagen_ruta):
    try:
        texto = pytesseract.image_to_string(Image.open(imagen_ruta), lang="spa")
        return texto
    except Exception as e:
        print(f"Error al escanear texto: {e}")
        return ""