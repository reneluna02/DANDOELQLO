from PyQt5.QtWidgets import QMainWindow, QPushButton, QVBoxLayout, QWidget
from database import init_db, agregar_cliente

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestión de Clientes")
        self.setGeometry(100, 100, 800, 600)

        # Layout principal
        layout = QVBoxLayout()

        # Botón para agregar cliente
        btn_agregar = QPushButton("Agregar Cliente")
        btn_agregar.clicked.connect(self.agregar_cliente)
        layout.addWidget(btn_agregar)

        # Configuración del widget central
        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        # Inicializar base de datos
        init_db()

    def agregar_cliente(self):
        agregar_cliente("René", "Empresa XYZ", "CDMX", 19.432608, -99.133209, True, "Método A")
        print("Cliente agregado.")