import sqlite3

def init_db():
    conn = sqlite3.connect("clientes.db")
    cursor = conn.cursor()

    # Tabla de clientes
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        razon_social TEXT,
        ubicacion TEXT,
        latitud REAL,
        longitud REAL,
        apto_venta BOOLEAN DEFAULT 0,
        metodo_trabajo TEXT
    )
    """)

    # Tabla de subclientes
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subclientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_id INTEGER,
        nombre TEXT,
        FOREIGN KEY (cliente_id) REFERENCES clientes (id)
    )
    """)

    # Tabla de recordatorios
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS recordatorios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_id INTEGER,
        fecha_hora DATETIME,
        mensaje TEXT,
        FOREIGN KEY (cliente_id) REFERENCES clientes (id)
    )
    """)

    # Tabla de empleados
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS empleados (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        datos_escaneados TEXT
    )
    """)

    conn.commit()
    conn.close()

def agregar_cliente(nombre, razon_social, ubicacion, latitud, longitud, apto_venta, metodo_trabajo):
    conn = sqlite3.connect("clientes.db")
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO clientes (nombre, razon_social, ubicacion, latitud, longitud, apto_venta, metodo_trabajo)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (nombre, razon_social, ubicacion, latitud, longitud, apto_venta, metodo_trabajo))
    conn.commit()
    conn.close()