import folium

def generar_mapa(clientes):
    mapa = folium.Map(location=[19.432608, -99.133209], zoom_start=12)  # CDMX
    for cliente in clientes:
        folium.Marker(
            location=[cliente['latitud'], cliente['longitud']],
            popup=f"{cliente['nombre']} - {cliente['ubicacion']}"
        ).add_to(mapa)
    mapa.save("mapa.html")
    print("Mapa generado: mapa.html")