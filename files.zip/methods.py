from openpyxl import Workbook
from docx import Document

def exportar_metodos_excel(clientes):
    wb = Workbook()
    ws = wb.active
    ws.append(["ID", "Nombre", "Método de Trabajo"])
    for cliente in clientes:
        ws.append([cliente['id'], cliente['nombre'], cliente['metodo_trabajo']])
    wb.save("metodos_trabajo.xlsx")
    print("Exportado a metodos_trabajo.xlsx")

def generar_cartas_word(clientes):
    doc = Document()
    for cliente in clientes:
        doc.add_heading(f"Carta para {cliente['nombre']}", level=1)
        doc.add_paragraph(f"Método de trabajo: {cliente['metodo_trabajo']}")
        doc.add_page_break()
    doc.save("cartas_clientes.docx")
    print("Cartas generadas: cartas_clientes.docx")